
def printPicnic(itemsDict):
    left = 0
    right = 0
    for k,v in itemsDict.items():
        if len(k) > left:
            left = len(k) + 5
        if len(str(v)) > right:
            right = len(str(v)) + 2
    print('PICNIC ITEMS'.center(left + right, '-'))
    for k, v in itemsDict.items():
        print(k.ljust(left, '.') + str(v).rjust(right))


def displayInventory(inv):
    print('Inventory: ')
    total = 0
    for i in inv:
        print(str(inv[i]) + " " + i)
        total += inv[i]

    print('Total number of items: ' + str(total))

def addToInventory(inv, new):
    for i in new:
        inv[i] = inv.get(i,0) + 1
    displayInventory(inv)



def printPicnic(itemsDict):
    left = 0
    right = 0
    for i,o in itemsDict.items():
        if len(i) > left:
            left = len(i) + 5
        if len(str(o)) > right:
            right = len(str(o)) + 2
    print("PICNIC ITEMS".center(left + right, "-"))
    for k,v in itemsDict.items():
        print(k.ljust(left,".") + str(v).rjust(right))


import pyperclip, re

phoneRegex = re.compile(r'''(
    (\d{3}|\(\d{3}\))?
    (\s|-|\.)
    (\d{3})
    (\s|-|\.)
    (\d{4})
    (\s*(ext|e|ext.)\s*(\d{2,5}))?
  )''', re.VERBOSE)

emailRegex = re.compile(r'''
    [a-zA-Z0-9._%+-]+
    @
    [a-zA-Z0-9._%+-]+
    (\.[a-zA-Z]{2,4})
    )''', re.VERBOSE)

text = str(pyperclip.paste())
matches = []

for groups in phoneRegex.findall(text):
    phoneNum = '-'.join([groups[1],groups[3],groups[5]])
    if groups[8] != '':
        phoneNum += ' x' + groups[8]
    matches.append(phoneNum)
for groups in emailRegex.findall(text):
    matches.append(groups[0])

if len(matches) > 0:
    pyperclip.copy("\n".join(matches))
    print('Copied to clipboard: ')
    print('\n'.join(matches))
else:
    print('No phone numbers or emails addresses found in the text')


def strongPassword(password):
    if len(password) < 8:
        print('Password too short.')
    regex = re.compile(r'[A-Za-z0-9]{8}')
    match = regex.search(password)
