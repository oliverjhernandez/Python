#!/usr/local/bin/python3
# bulletAdder.py --- Simple program to modifiy text from the clipboard.

import pyperclip
text = pyperclip.paste()

lines = text.split('\n')
for i in lines:
  lines[i] = '* ' + lines[i]

text = '\n'.join(text)

pyperclip.copy()
