#!/usr/local/bin/python3
# Mad Libs simple program
# Go nuts!

print("Enter an adjective: ")
adj = input()
print("Enter an noun: ")
noun1 = input()
print("Enter an verb: ")
verb = input()
print("Enter an noun: ")
noun2 = input()

phrase = "The %s panda walked to the %s and then %s. A nearby %s was unaffected by these events." % (adj, noun1, verb, noun2)

print(phrase)
