def printPicnic(diccionario):
    left = 0
    right = 0
    for k,v in diccionario.items():
        if len(k) > left:
            left = len(k) + 5
        if len(str(v)) > right:
            right = len(str(v)) + 2
    print('PICNIC ITEMS'.center(left + right, '-'))
    for k, v in diccionario.items():
        print(k.ljust(left, '.') + str(v).rjust(right))

itemsDict = { "Nombre": "Vanessa", "Apellido": "Marquez", "Edad": 25  }

printPicnic(itemsDict)
