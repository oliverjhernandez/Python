#!/usr/local/bin/python3
# tablePrinter.py --- Simple python program to take a list of list and tabulate it.

tableData = [	['apples', 'oranges', 'cherries', 'banana'],
		['Alice', 'Bob', 'Carol', 'David'],
		['dogs', 'cats', 'moose', 'goose']	]

for i in tableData:
  length = [0] * len(tableData)
  for o in i:
    if len(o) > length[]:
      length[o] = len(i[o])

print(length)
